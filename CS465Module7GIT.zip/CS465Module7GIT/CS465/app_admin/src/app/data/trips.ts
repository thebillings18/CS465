export const trips = [
  {
    code: "GAL123",
    name: "Galapagos Adventure",
    length: "7 nights / 8 days",
    start: "2026-11-01T00:00:00Z",
    resort: "Santa Cruz",
    perPerson: 1895,
    image: "galapagos.jpg",
    description:
      "<p>Explore the Galapagos Islands with guided wildlife tours, pristine beaches, and comfortable lodging on Santa Cruz.</p><p>Perfect for travelers seeking a mix of adventure, nature, and relaxation.</p>",
  },
  {
    code: "ALP456",
    name: "Alpine Escape",
    length: "5 nights / 6 days",
    start: "2026-12-15T00:00:00Z",
    resort: "Zermatt",
    perPerson: 1299,
    image: "alps.jpg",
    description:
      "<p>Ski the Swiss Alps and unwind in the peaceful mountain village of Zermatt.</p><p>Enjoy scenic trails, cozy accommodations, and breathtaking alpine views throughout your stay.</p>",
  },
  {
    code: "SAF789",
    name: "Safari Expedition",
    length: "10 nights / 11 days",
    start: "2027-01-20T00:00:00Z",
    resort: "Serengeti Lodge",
    perPerson: 2499,
    image: "safari.jpg",
    description:
      "<p>Experience the African savannah up close with guided wildlife drives and luxury lodging at Serengeti Lodge.</p><p>Unforgettable encounters with the region’s diverse animal life await.</p>",
  }
];
