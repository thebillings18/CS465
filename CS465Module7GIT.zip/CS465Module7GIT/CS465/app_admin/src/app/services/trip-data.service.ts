import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Trip } from '../models/trip';
import { AuthenticationService } from './authentication.service';

@Injectable({
  providedIn: 'root'
})
export class TripDataService {

  url = 'http://localhost:3000/api/trips';

  constructor(
    private http: HttpClient,
    private authService: AuthenticationService
  ) {}

  // Build Authorization header from stored JWT
  private authHeaders(): { headers: HttpHeaders } {
    const token = this.authService.getToken();
    return {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      })
    };
  }

  // Fetch all trips (public — no auth needed)
  getTrips(): Observable<Trip[]> {
    return this.http.get<Trip[]>(this.url);
  }

  // Fetch a single trip by tripCode (public)
  getTrip(tripCode: string): Observable<Trip> {
    return this.http.get<Trip>(`${this.url}/${tripCode}`);
  }

  // Add a new trip (protected)
  addTrip(formData: Trip): Observable<Trip> {
    return this.http.post<Trip>(this.url, formData, this.authHeaders());
  }

  // Update an existing trip (protected)
  updateTrip(tripCode: string, formData: Trip): Observable<Trip> {
    return this.http.put<Trip>(`${this.url}/${tripCode}`, formData, this.authHeaders());
  }

  // Delete an existing trip (protected)
  deleteTrip(tripCode: string): Observable<void> {
    return this.http.delete<void>(`${this.url}/${tripCode}`, this.authHeaders());
  }
}
