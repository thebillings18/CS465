import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { Router } from "@angular/router";
import { TripDataService } from '../services/trip-data.service';
import { ReactiveFormsModule } from '@angular/forms';

@Component({
  selector: 'app-add-trip',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule], // Added ReactiveFormsModule
  templateUrl: './add-trip.component.html',
  styleUrls: ['./add-trip.component.css']
})
export class AddTripComponent implements OnInit {
  public addForm!: FormGroup; // Made addForm public
  submitted = false;

  constructor(
    private formBuilder: FormBuilder,
    private router: Router,
    private tripService: TripDataService
  ) { }

ngOnInit() {
  this.addForm = this.formBuilder.group({
    _id: [],
    code: ["", Validators.required],    // required — used as the DB lookup key for edit/delete
    name: ["", Validators.required],
    length: [""],
    start: [""],
    resort: [""],
    perPerson: [""],
    image: [""],
    description: [""]
  });
}

  public onSubmit() {
    this.submitted = true;
    if (this.addForm.valid) {
      this.tripService.addTrip(this.addForm.value)
        .subscribe({
          next: (data: any) => {
            console.log(data);
            this.router.navigate(['']);
          },
          error: (error: any) => {
            console.log('Error: ' + error);
          }
        });
    }
  }

  get f() {
    return this.addForm.controls;
  }
}
