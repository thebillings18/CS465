const passport = require('passport');
const mongoose = require('mongoose');
const User = mongoose.model('users');
const jwt = require('jsonwebtoken');

// Generate a signed JWT for a given user
const generateJwt = (user) => {
  const expiry = new Date();
  expiry.setDate(expiry.getDate() + 7); // token valid for 7 days

  return jwt.sign(
    {
      _id: user._id,
      email: user.email,
      name: user.name,
      exp: parseInt(expiry.getTime() / 1000, 10)
    },
    process.env.JWT_SECRET || 'travlr-secret-key-change-in-production'
  );
};

// POST /api/register
const register = async (req, res) => {
  if (!req.body.name || !req.body.email || !req.body.password) {
    return res.status(400).json({ message: 'All fields required: name, email, password' });
  }

  try {
    const existing = await User.findOne({ email: req.body.email.toLowerCase() });
    if (existing) {
      return res.status(409).json({ message: 'Email already registered' });
    }

    const user = new User();
    user.name = req.body.name;
    user.email = req.body.email;
    user.setPassword(req.body.password);

    await user.save();

    const token = generateJwt(user);
    res.status(200).json({ token });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// POST /api/login
const login = async (req, res) => {
  if (!req.body.email || !req.body.password) {
    return res.status(400).json({ message: 'All fields required: email, password' });
  }

  try {
    const user = await User.findOne({ email: req.body.email.toLowerCase() });
    if (!user || !user.validPassword(req.body.password)) {
      return res.status(401).json({ message: 'Incorrect email or password' });
    }

    const token = generateJwt(user);
    res.status(200).json({ token });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

module.exports = { register, login };
