const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

const userSchema = new mongoose.Schema({
  name: { type: String, required: true },
  email: { type: String, required: true, unique: true, lowercase: true },
  hash: { type: String, required: true }
});

// Hash the password before saving
userSchema.methods.setPassword = function (password) {
  this.hash = bcrypt.hashSync(password, 10);
};

// Validate a password against the stored hash
userSchema.methods.validPassword = function (password) {
  return bcrypt.compareSync(password, this.hash);
};

const User = mongoose.model('users', userSchema);
module.exports = User;
