const mongoose = require('mongoose');

// Define the trip schema
const tripSchema = new mongoose.Schema({
    code: { type: String, index: true },
    name: { type: String, required: true, index: true },   // ONLY required field
    length: { type: String },
    start: { type: Date },
    resort: { type: String },
    perPerson: { type: String },
    image: { type: String },
    description: { type: String }
});

const Trip = mongoose.model('trips', tripSchema);
module.exports = Trip;
