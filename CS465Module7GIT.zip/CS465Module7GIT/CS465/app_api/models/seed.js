// Bring in the DB connection and load the Trip schema
const mongoose = require('./db');
require('./travlr'); // registers the schema

// Now retrieve the model
const Trip = mongoose.model('trips');

// Read seed data from JSON file
const fs = require('fs');
const trips = JSON.parse(fs.readFileSync('./data/trips.json', 'utf8'));

// Delete any existing records, then insert seed data
const seedDB = async () => {
  await Trip.deleteMany({});
  await Trip.insertMany(trips);
};

// Close the MongoDB connection and exit
seedDB().then(async () => {
  await mongoose.connection.close();
  process.exit(0);
});
