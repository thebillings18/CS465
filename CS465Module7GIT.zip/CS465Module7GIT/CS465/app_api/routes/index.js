const express = require('express');
const router = express.Router();
const tripsController = require('../controllers/trips');
const authController = require('../controllers/authentication');
const { authenticate } = require('../middleware/authenticate');

// ── Auth endpoints (public) ──────────────────────────────────────────────────
router.post('/register', authController.register);
router.post('/login',    authController.login);

// ── Trip endpoints ───────────────────────────────────────────────────────────
// GET all trips (public) | POST new trip (protected)
router
  .route('/trips')
  .get(tripsController.tripsList)
  .post(authenticate, tripsController.tripsAddTrip);

// DELETE trip by MongoDB _id (protected)
router
  .route('/trips/id/:id')
  .delete(authenticate, tripsController.tripsDeleteById);

// GET one trip (public) | PUT update (protected) | DELETE (protected)
router
  .route('/trips/:tripCode')
  .get(tripsController.tripReadOne)
  .put(authenticate, tripsController.tripsUpdateTrip)
  .delete(authenticate, tripsController.tripsDeleteTrip);

module.exports = router;
