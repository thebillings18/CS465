const newsData = require('../../data/news.json');

module.exports.news = function(req, res) {
    res.render('news', {
        title: 'Latest News',
        articles: newsData
    });
};
