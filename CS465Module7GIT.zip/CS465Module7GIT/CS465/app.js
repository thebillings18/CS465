const express = require('express');
const path = require('path');
const hbs = require('hbs');
const mongoose = require('mongoose');

// Initialize Express
const app = express();
const PORT = process.env.PORT || 3000;

// ⭐ REQUIRED FOR POSTMAN + ANGULAR ⭐
app.use(express.json());

// CORS — allow Angular SPA (port 4200) to call this API (port 3000)
app.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', 'http://localhost:4200');
  res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.header('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') {
    return res.sendStatus(200);
  }
  next();
});

// Connect to MongoDB via Mongoose
require('./app_api/models/db');

// Set up Handlebars as the view engine
app.set('view engine', 'hbs');
app.set('views', path.join(__dirname, 'app_server', 'views'));

// Register partials
hbs.registerPartials(path.join(__dirname, 'app_server', 'views', 'partials'));

// Serve static files
app.use(express.static(path.join(__dirname, 'public')));

// Frontend routes
const indexRouter = require('./app_server/routes/index');
const roomsRouter = require('./app_server/routes/rooms');
const travelRouter = require('./app_server/routes/travel');
const mealsRouter = require('./app_server/routes/meals');
const newsRouter = require('./app_server/routes/news');
const contactRouter = require('./app_server/routes/contact');
const aboutRouter = require('./app_server/routes/about');

// API routes
const apiRouter = require('./app_api/routes/index');

// Use routes
app.use('/', indexRouter);
app.use('/rooms', roomsRouter);
app.use('/travel', travelRouter);
app.use('/meals', mealsRouter);
app.use('/news', newsRouter);
app.use('/contact', contactRouter);
app.use('/about', aboutRouter);

// API
app.use('/api', apiRouter);

// Start server
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
